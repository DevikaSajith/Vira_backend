package com.example.vira_dashboard

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
